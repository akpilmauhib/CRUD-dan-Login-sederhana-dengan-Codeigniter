<div class="wrapper">
    <div class="sidebar" data-color="purple" data-image="assets/img/sidebar-5.jpg">
    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                    Management Salon Christy
                </a>
            </div>

            <ul class="nav">
                <li >
                    <a href="<?php echo base_url(); ?>admin/barang">
                        <!--<i class="pe-7s-graph"></i>-->
                        <i class="pe-7s-news-paper"></i>
                        <p>Barang</p>
                    </a>
                </li>
				
				<li>
                    <a href="<?php echo base_url(); ?>admin/pelanggan">
                        <!--<i class="pe-7s-graph"></i>-->
						<i class="pe-7s-news-paper"></i>
                        <p>Pelanggan</p>
                    </a>
                </li>
				
				
            </ul>
    	</div>
    </div>

    <div class="main-panel">
	
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard Admin</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    Lainya
                                    <b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                              </ul>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>login/logout">
                               Log out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>